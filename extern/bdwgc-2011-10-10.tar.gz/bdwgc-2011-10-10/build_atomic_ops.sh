#!/bin/sh
P=`pwd`/libatomic_ops-install
cd libatomic_ops
./configure --prefix=$P
$MAKE CC=$CC install
